<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="UTF-8">
  <title>EZRA VIDEO ADS</title>
  <link rel="icon" type="image/x-icon" href="image/Favicon.png">
  <link rel="stylesheet" href="ads2.css">
</head>
<body>
  <div class="btn">
    <div class="play"></div>
    <p>Play Video Ads</p>
  </div>
  <div class="clip">
    <video src="image/SmacEnrollNow.mp4" controls="true"></video>
    <a href="order.php" class="close">Close</a> 
  </div>
  <script type="text/javascript">
      let btn = document.querySelector(".btn");
      let clip = document.querySelector(".clip");
      let video = document.querySelector("video");
      let close = document.querySelector(".close");
      btn.onclick = function(){
        btn.classList.add("active");
        clip.classList.add("active");
        video.currentTime = 0;
        video.play();
      }
      close.onclick = function(){
        btn.classList.remove("active");
        clip.classList.remove("active");
        video.pause(); 
      }
  </script>
</body>
</html>