<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>EZRA | Order</title>
    <link rel="icon" type="image/x-icon" href="image/icon.png">
  <link href="order.css" rel="stylesheet" type="text/css" />
</head>
  
<section>
  <div class="container">
    <form action="https://formspree.io/f/xjvdjldw" method="POST" id="my-form">

    <body>
      <p> EZRA THIS MOD. PAYMENT ONLY FOR COD </p>
         <div class="form-group">
        <label for="firstName"> Full Name</label>
        <input type="text" id="firstName" name="firstName">
      </div>

      <div class="form-group">
        <label for="latsName">Email</label>
        <input type="text" id="Email" name="Email">
      </div>

      <div class="form-group">
        <label for="Contact Number">Contact Number</label>
        <input type="number" id="Number" name="Number">
      </div>
      
      <div class="form-group">
        <label for="Address">Address</label>
        <input type="text" id="Address" name="Address">
      </div>
      
      <div class="form-group">
        <label for="Name Order">Name Order </label>
        <input type="Text" id="order" name="order">
      </div>
            
      <div class="form-group">
        <label for="HM">How Many </label>
        <input type="number" id="HM" name="HM">
      </div>

      <div class="form-group">
        <label for="massage">Message</label>
       <input type="Text" id="Message" name="Message">
      </div>

      <button type="submit">Submit</button>
    </form>
  </div>
  <div id="status"></div>
</section>

      <!--Footer-->

    <footer>
        <div class="footer_main">

            <div class="footer_tag">
                <h2>Location</h2>
                <p>Philippines</p>
                <p>USA</p>
                <p>Korea</p>
                <p>Japan</p>
                <p>Italy</p>
            </div>

            <div class="footer_tag">
                <h2>Contact</h2>
                <p>09222 ikaw n bahala</p>
                <p>0987456321</p>
                <p>SmacBacor@gmail.com</p>
                <p>SmacBacoor@gmail.com</p>
            </div>

            <div class="footer_tag">
                <h2>Our Service</h2>
                <p>Fast Delivery</p>
                <p>Easy Payments</p>
                <p>24 x 7 Service</p>
            </div>

            <div class="footer_tag">
                <h2>Follows</h2>
              <a href="https://www.facebook.com/smacbacoor.official">
                <i class="fa-brands fa-facebook-f">SmacBacoor</i>
                <i class="fa-brands fa-twitter">SmacBacoor</i>
                <i class="fa-brands fa-instagram">SmacBacoor</i> </a>
            </div>

        </div>

        <p class="end">Design by<span><i class="fa-solid fa-face-grin"></i> ANTONIO / EZRA COMMUNITY</span></p>

    </footer>
 
</body>
</html>
   