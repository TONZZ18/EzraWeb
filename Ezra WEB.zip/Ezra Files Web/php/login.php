<!DOCTYPE html>
<html> 
<head>
   <head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" conte
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login.css">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">

    <title>EZRA | Login</title>
     <link rel="icon" type="image/x-icon" href="image/icon.png">
</head>

<body>
  <body>
<section id="Home">
        <nav>
            <div class="logo">
                <img src="image/logo.png">
            </div>
   <div class="box">
    <div class="container">

        <div class="top">
            <span>BETA ACCOUNT</span>
            <span>USE YOUR SMAC ACCOUNT / ADMIN ADMIN</span>
            <header>Login</header>
        </div>

        <div class="input-field">
            <input type="text" class="input" placeholder="Username" id="">
            <i class="bx bx-user"></i>
        </div>

        <div class="input-field">
            <input type="Password" class="input" placeholder="Password" id="">
            <i class="bx bx-lock-alt"></i>
        </div>

        <div class="input-field">
          <a href="https://ezra.phshop.repl.co/"</a>
              <input type="submit" class="submit" value="Login" id=""> 
        </div>

        <div class="two-col">
            <div class="one">
               <input type="checkbox" name="" id="check">
               <label for="check"> Remember Me</label>
            </div>
            <div class="two">
                <label><a href="#">Forgot password</a></label>
            </div>
        </div>
    </div>
          <script>
            function func () {
            var email = document.getElementByID("Username").value;
            var pass = document.ElementByID("password").value
              if (email == 'ian025intep@gmail.com') && pass == '123'{
                alert("success full !")
                window.location.assign("index.html")
              }
            }     
            else{
              alert("Wrong enter invald")
            }
         }
          </script>
</div>  
</body>
